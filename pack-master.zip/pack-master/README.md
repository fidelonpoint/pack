# pack
Google Developer Groups Nigeria Waste Management Community Project

<Strong>Instruction<Strong/>
<ol>
<li>Please clone/pull this repo, work on it locally</li>
<li>When Pushing, you need to create a branch and push to it</li> 
<li>Merging to Master will be done once you submit a merge request.</li>
</ol>
